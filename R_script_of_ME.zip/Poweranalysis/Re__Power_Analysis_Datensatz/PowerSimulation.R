# Load necessary library
library(dplyr)
library(readr)
require(lmerTest)
# Read the CSV file
data <- read_csv("R_script_of_ME/Poweranalysis/Re__Power_Analysis_Datensatz/Data moderated mediation analysis.csv")
risk_group <- data %>% filter(Risk == 1) #we take the data only from risk group, as the experiment will be conducted in different heights

var_trustSI <- var(risk_group$TrustSum/11) #our Original study measured trust as the average of the items
(sd_trustSI <-sqrt(var_trustSI)) #we will use this standard error 
(mean_trustSI <- mean((risk_group$TrustSum/11))) #we will use this mean value

n <- 40 #number of subjects in each rel group

#Create the factors
nexp <- 6 #number of exposures
nrel <- 2 #number of rel groups
rel.labels <- c("HI","LO")
rel <- factor(rep(1:nrel,each=nexp*n),labels = rel.labels) #2 levels of reliability
ID <- factor(c(rep(1:n,each=nexp),rep((n+1):(2*n),each=nexp))) #group Hi (high) reliability will have ID 1-n, LO reliability: ID n+1 to n*2
exp <- factor(c(rep(1:nexp, n))) #we will measure exposure 6 times 


df <-data.frame(ID,exp,rel)

#effect coding 
contrasts(df$exp) <- contr.sum(nexp)
contrasts(df$rel) <- contr.sum(2)

#Design matrix of fixed effects
X <- model.matrix(~rel*exp,data = df)

sig <- sd_trustSI #theoretical standard error, line 11


# true effect sizes: partial omega squared as effect size measures: choose effect size for each factor
w2p.rel <- 0.11
w2p.exp <- 0.06
w2p.interaction <- 0.06
alpha <-0.05


# Effect standard deviations can now be derived from the respective omega squared above (w2)
sig.rel <- sqrt(w2p.rel*sig^2/(1-w2p.rel)) #for reliablity
sig.exp <- sqrt(w2p.exp*sig^2/(1-w2p.exp)) #for exposure
sig.interaction <- sqrt(w2p.interaction*sig^2/(1-w2p.interaction)) #and for the interaction

#generate random effects based on the effect standard deviations 
eff.rel <- scale(runif(nrel))*sig.rel
eff.exp <- scale(runif(nexp))*sig.exp

eff.interaction <- matrix(0,nrow = nrel, ncol = nexp)
for(i in 1:(nrel-1)){
 eff.interaction[i,] <- scale(runif(nexp)) 
}
 
eff.interaction[nrel,] <- -colSums(eff.interaction)
eff.interaction <- sig.interaction*eff.interaction/sd(eff.interaction)

#pack the fixed effects found above in a Parameter vector beta 
mu <- mean_trustSI #theoretical grand mean calculated from data, line 12
rel.params <- eff.rel[1:(nrel-1)]
exp.params <- eff.exp[1:(nexp-1)]
interaction.params <- as.vector(eff.interaction[1:(nrel-1),1:(nexp-1)])

beta <- c(mu,rel.params,exp.params,interaction.params) 

#standard deviations of random effects
sdranef <- c(0.77,0.77) #taken from the original study, here we have to groups of reliability

#let s simulate a data
sim.data <- function(){ #fixed effects
  mu.i <- X%*%beta
  b <- NULL
  kk <- 0
  for(k in rel.labels){ #random effect
    kk <- kk + 1
    for(j in df$ID[df$rel==k]){
      b[df$ID==j & df$rel==k] <- rnorm(1,0,sdranef[kk])
    }
  }
  e <- rnorm(2*nexp*n,0,sig) #residual error
  return(mu.i+b+e)
}


sims <- 10000 #number of simulations
#create empty matrices to store the values
Fvalues <- matrix(0,sims,3)
pvalues <- matrix(0,sims,3)

for(k in 1:sims){ #each simulation is k
  df$cen_mean <- sim.data()
  
  model3_formula <- cen_mean ~ rel * exp + (rel | ID)
  
  # Fit the model using lmer
  suppressWarnings(s_model <- lmer(model3_formula, data = df))
  tmp <- anova(s_model)[,5:6] #5,6 are the positions of F- and pvalues
  Fvalues[k,] <- tmp$`F value` # F values from anova will be listed in a row of tmp (temporatory tmp store)
  pvalues[k,] <- tmp$`Pr(>F)`
  
  if(!k%%(sims/10)) cat(".")
}

power <- matrix(colMeans(pvalues<alpha),3,1)

row.names(power) <- c("rel","exp","rel:exp")
power


quantile_95_rel <- quantile(Fvalues[,1], 0.95)
quantile_95_exp <- quantile(Fvalues[,2], 0.95)
quantile_95_interaction <- quantile(Fvalues[,3], 0.95)

par(mfrow=c(1,3))
hist(Fvalues[,1],main=paste("Haupteffekt rel, Power ",power[1]))
abline(v=quantile_95_rel, col="red", lwd=1)

hist(Fvalues[,2],main=paste("Haupteffekt exp, Power ",power[2]))
abline(v=quantile_95_exp, col="red", lwd=1)

hist(Fvalues[,3],main=paste("Interaktion exp:rel, Power ",power[3]))
abline(v=quantile_95_interaction, col="red", lwd=1)

par(mfrow=c(1,1))





